import { combineReducers } from 'redux'
import usersReducer from './users.reducer'
import postReducer from './post.reducer'
import errorReducer from './error.reducer'

export default combineReducers({
    usersReducer,
    postReducer,
    errorReducer
})