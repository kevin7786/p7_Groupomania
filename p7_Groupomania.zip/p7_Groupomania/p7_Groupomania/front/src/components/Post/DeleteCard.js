import React from "react";
import { useDispatch } from "react-redux";
import { deletePost } from "../../actions/post.actions";
// import { BrowserRouter as Route } from "react-router-dom";
// import Home from "../../pages/Home";

const DeleteCard = (props) => {
  console.log('props',props);
  const dispatch = useDispatch();

  const deleteQuote = () => dispatch(deletePost(props.id));
   //navigate(path home page )
  //  <Route path="/" element={<Home />} />

  return (
    <div
      onClick={() => {
        if (window.confirm("Voulez-vous supprimer cet article ?")) {
          deleteQuote();
        }
      }}
    >
      <img src="../img/icons/trash.svg" alt="trash" />
   
    </div>
  );
};

export default DeleteCard;