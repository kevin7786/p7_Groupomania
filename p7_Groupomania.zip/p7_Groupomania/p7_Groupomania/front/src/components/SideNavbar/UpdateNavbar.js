import LeftNav from '../LeftNav';

const UpdateNavbar = () => {
    return (
        <div className="profil-container">
            <LeftNav />
        </div>
    )
}

export default UpdateNavbar