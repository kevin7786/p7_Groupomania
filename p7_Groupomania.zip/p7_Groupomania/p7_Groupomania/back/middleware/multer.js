const multer = require("multer")

//stokage sur le disque dur
const storage = multer.diskStorage({
    destination: "images/",
    filename: function (req, file ,cb) {
        cb(null, makeFilename(req, file))
    }
})

//nom unique , replace les espaces par "-"
function makeFilename(req, file) {
    const filename = `${Date.now()}-${file.originalname}` .replace(/\s/g, "-")
    file.filename = filename
    return filename
}

const upload = multer({storage: storage})

module.exports = {upload}